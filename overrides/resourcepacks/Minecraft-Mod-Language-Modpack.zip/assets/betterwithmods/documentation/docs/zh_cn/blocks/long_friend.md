![长条的朋友](block:betterwithmods:long_friend)

:)

(首先你要找到一条橙色的,嘴奇长无比的狗——译者)